//notes.js
